package tech.soit.flutter_tetris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
